async function getMatchData() {
  const statusElement = document.getElementById("status");
  const matchesElement = document.getElementById("matches");
  const refreshButton = document.getElementById("refreshButton");

  try {
    const response = await fetch("https://api.cricapi.com/v1/currentMatches?apikey=78d29145-c822-431c-8634-28a0e9c4fd14&offset=0");
    const data = await response.json();

    if (data.status != "success") {
      throw new Error("Failed to fetch match data");
    }

    const matchesList = data.data;
    if (!matchesList) {
      throw new Error("No matches found");
    }

    const relevantData = matchesList.map(match => {
      const matchName = match.name || "Unknown";
      const matchStatus = match.status || "No status available";
      const matchScore = match.score ? match.score.map(score => `(${score.r}/${score.w}, ${score.o} overs, ${score.inning})`).join(" - ") : "No score available";
      return { name: matchName, status: matchStatus, score: matchScore };
    });
    console.log(relevantData);

    matchesElement.innerHTML = relevantData.map(match => `
      <li>
        <div class="match-info">
          <div>
            <p class="match-name">${match.name}</p>
            <p class="match-status">${match.status}</p>
          </div>
          <div>
            <p class="match-score">${match.score}</p>
          </div>
        </div>
      </li>
    `).join('');
    statusElement.textContent = ""; 
    refreshButton.style.display = "inline-flex"; 
  } catch (error) {
    console.error("Error fetching match data:", error);
    statusElement.textContent = "Error fetching match data";
    statusElement.classList.add("error");
    refreshButton.style.display = "inline-flex"; 
  }
}

document.getElementById("refreshButton").addEventListener("click", () => {
  const statusElement = document.getElementById("status");
  const refreshButton = document.getElementById("refreshButton");

  statusElement.textContent = "Loading matches...";
  statusElement.classList.remove("error");
  document.getElementById("matches").innerHTML = "";
  refreshButton.style.display = "none"; 
  getMatchData();
});


getMatchData();
